import { useState } from 'react';

export default function AIChat() {
  const [input, setInput] = useState('');
  const [chatLog, setChatLog] = useState([]);

  const handleSend = () => {
    if (!input.trim()) return;
    setChatLog([...chatLog, { from: 'user', text: input }]);
    // Simulate AI response with a placeholder
    setTimeout(() => {
      setChatLog((log) => [...log, { from: 'arc', text: 'Strategy tips: Try aiming for the edges!' }]);
    }, 1000);
    setInput('');
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-6 flex flex-col max-w-3xl mx-auto">
      <h1 className="text-4xl font-bold mb-6">💬 Talk to Arc</h1>
      <div className="flex-1 overflow-auto mb-4 border border-gray-700 rounded p-4 space-y-2">
        {chatLog.length === 0 && <p className="text-gray-400">Start the conversation...</p>}
        {chatLog.map((msg, i) => (
          <div
            key={i}
            className={msg.from === 'user' ? 'text-right' : 'text-left'}
          >
            <span className={`inline-block px-4 py-2 rounded-lg ${msg.from === 'user' ? 'bg-blue-600' : 'bg-gray-700'}`}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div className="flex space-x-2">
        <input
          className="flex-1 rounded px-4 py-2 text-black"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask for arcade strategy..."
        />
        <button
          onClick={handleSend}
          className="bg-blue-600 px-4 py-2 rounded disabled:opacity-50"
          disabled={!input.trim()}
        >
          Send
        </button>
      </div>
    </main>
  );
}
