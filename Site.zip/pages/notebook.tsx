import { useState } from 'react';

export default function Notebook() {
  const [notes, setNotes] = useState('');

  const handleDownload = () => {
    const blob = new Blob([notes], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'arc-win-notes.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-6 max-w-3xl mx-auto flex flex-col">
      <h1 className="text-4xl font-bold mb-6">📓 Notebook</h1>
      <textarea
        className="flex-grow bg-gray-700 p-4 rounded resize-none focus:outline-none"
        placeholder="Write notes about machines, payouts, strategies..."
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
      />
      <button
        onClick={handleDownload}
        className="mt-4 bg-yellow-500 hover:bg-yellow-600 px-6 py-3 rounded self-end"
      >
        Download Notes
      </button>
    </main>
  );
}
