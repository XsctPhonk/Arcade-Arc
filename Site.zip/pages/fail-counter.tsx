import { useState } from 'react';

export default function FailCounter() {
  const [fails, setFails] = useState(0);
  const [goal, setGoal] = useState('');
  const [payout, setPayout] = useState('');
  const [odds, setOdds] = useState(null);
  const [message, setMessage] = useState('');

  const addFail = () => setFails(fails + 1);

  const calculateOdds = () => {
    const payoutNum = Number(payout);
    const goalNum = Number(goal);
    if (isNaN(payoutNum) || isNaN(goalNum) || fails === 0) {
      setMessage('Please enter valid numbers and fail at least once.');
      setOdds(null);
      return;
    }
    // Simple odds estimation: chance = payout / (fails + 1)
    const chance = payoutNum / (fails + 1);
    setOdds(chance.toFixed(2));

    if (goalNum <= payoutNum) {
      setMessage('You already reached or exceeded your goal!');
    } else if (goalNum - payoutNum < chance) {
      setMessage('You are close to your goal! Keep going!');
    } else {
      setMessage('It might be tough to reach your goal soon.');
    }
  };

  const reset = () => {
    setFails(0);
    setGoal('');
    setPayout('');
    setOdds(null);
    setMessage('');
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-6 flex flex-col max-w-md mx-auto">
      <h1 className="text-4xl font-bold mb-6">📉 Fail Counter</h1>
      <div className="mb-4">
        <button
          onClick={addFail}
          className="bg-red-600 px-6 py-3 rounded mr-4"
        >
          Fail
        </button>
        <button
          onClick={() => {
            const payoutInput = prompt('Enter tickets payout:');
            const goalInput = prompt('Enter your ticket goal:');
            if (payoutInput !== null && goalInput !== null) {
              setPayout(payoutInput);
              setGoal(goalInput);
              calculateOdds();
            }
          }}
          className="bg-green-600 px-6 py-3 rounded"
        >
          Payout
        </button>
      </div>
      <p>Fails: {fails}</p>
      {odds !== null && (
        <>
          <p>Estimated odds to win soon: {odds}</p>
          <p>{message}</p>
        </>
      )}
      <button
        onClick={reset}
        className="mt-6 bg-gray-700 px-6 py-3 rounded"
      >
        Reset
      </button>
    </main>
  );
}
