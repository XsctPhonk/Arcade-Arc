import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-700 to-blue-900 text-white p-6">
      <h1 className="text-5xl font-bold mb-8">Welcome to Arc-win!</h1>
      <nav className="flex flex-col space-y-4 w-full max-w-md">
        <Link href="/ai-chat">
          <a className="bg-blue-600 hover:bg-blue-700 px-6 py-4 rounded-2xl shadow-lg text-center">
            💬 Talk to Arc (AI Chat)
          </a>
        </Link>
        <Link href="/fail-counter">
          <a className="bg-red-600 hover:bg-red-700 px-6 py-4 rounded-2xl shadow-lg text-center">
            📉 Fail Counter
          </a>
        </Link>
        <Link href="/notebook">
          <a className="bg-yellow-500 hover:bg-yellow-600 px-6 py-4 rounded-2xl shadow-lg text-center">
            📓 Notebook
          </a>
        </Link>
      </nav>
    </main>
  );
}
